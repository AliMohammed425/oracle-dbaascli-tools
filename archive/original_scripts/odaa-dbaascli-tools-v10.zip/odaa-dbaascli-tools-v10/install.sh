#!/usr/bin/env bash
set -Eeuo pipefail
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DST="${1:-/home/opc/tools/odaa-dbaascli-tools}"
mkdir -p "$DST"
cp -R "$SRC/bin" "$SRC/lib" "$SRC/docs" "$SRC/config" "$DST/"
mkdir -p "$DST/logs" "$DST/reports"
chmod 750 "$DST"/bin/*.sh "$DST"/lib/*.sh
echo "Installed: $DST"
echo "Menu: $DST/bin/odaa_db_migration.sh"
echo "CLI help: $DST/bin/odaa_db_migration_pdb.sh -H"
