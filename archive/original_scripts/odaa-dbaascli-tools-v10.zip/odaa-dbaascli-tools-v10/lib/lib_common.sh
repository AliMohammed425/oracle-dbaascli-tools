#!/usr/bin/env bash
set -o pipefail
ODAA_HOME="${ODAA_HOME:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
ODAA_BIN="${ODAA_HOME}/bin"
ODAA_LOG="${ODAA_HOME}/logs"
ODAA_REPORT="${ODAA_HOME}/reports"
ODAA_ENGINE="${ODAA_BIN}/odaa_db_migration_pdb.sh"
mkdir -p "$ODAA_LOG" "$ODAA_REPORT"
ts(){ date '+%Y-%m-%d %H:%M:%S'; }
info(){ printf '%s INFO : %s\n' "$(ts)" "$*"; }
ok(){ printf '%s OK   : %s\n' "$(ts)" "$*"; }
warn(){ printf '%s WARN : %s\n' "$(ts)" "$*" >&2; }
die(){ printf '%s ERROR: %s\n' "$(ts)" "$*" >&2; exit 1; }
run_engine(){ [[ -x "$ODAA_ENGINE" ]] || die "Core engine not executable: $ODAA_ENGINE"; "$ODAA_ENGINE" "$@"; }
prompt_value(){ local n="$1" l="$2" d="${3:-}" v=""; if [[ -n "$d" ]]; then read -r -p "$l [$d]: " v; v="${v:-$d}"; else read -r -p "$l: " v; fi; printf -v "$n" '%s' "$v"; }
prompt_secret(){ local n="$1" l="$2" v=""; read -r -s -p "$l: " v; printf '\n'; printf -v "$n" '%s' "$v"; }
