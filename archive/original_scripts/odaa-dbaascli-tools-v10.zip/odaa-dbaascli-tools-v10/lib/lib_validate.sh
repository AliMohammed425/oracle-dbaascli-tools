#!/usr/bin/env bash
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib_common.sh"
validate_environment(){
  local cdb=""; prompt_value cdb "CDB name"
  command -v /usr/bin/dbaascli >/dev/null 2>&1 && ok "DBaaSCLI available" || warn "DBaaSCLI not found"
  [[ -x /usr/bin/sudo ]] && ok "sudo available" || warn "sudo not found"
  run_engine -l -c "$cdb"
}
