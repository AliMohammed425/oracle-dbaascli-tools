#!/usr/bin/env bash
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib_common.sh"
enable_snapshot_test(){ local cdb="" src="" tgt=""; prompt_value cdb "CDB name"; prompt_value src "Refreshable PDB"; prompt_value tgt "Writable test PDB"; run_engine -E -c "$cdb" -p "$src" -t "$tgt"; }
disable_snapshot_test(){ local cdb="" src="" tgt=""; prompt_value cdb "CDB name"; prompt_value src "Refreshable PDB"; prompt_value tgt "Snapshot test PDB"; run_engine -X -c "$cdb" -p "$src" -t "$tgt"; }
