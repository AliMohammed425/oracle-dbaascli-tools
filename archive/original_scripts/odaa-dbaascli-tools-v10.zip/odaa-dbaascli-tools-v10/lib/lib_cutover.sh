#!/usr/bin/env bash
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib_common.sh"
final_cutover(){ local cdb="" pdb=""; prompt_value cdb "Target CDB"; prompt_value pdb "Refreshable PDB"; run_engine -C -c "$cdb" -p "$pdb"; }
refreshable_switchover(){
  local src="" tgt="" sdb="" scan="" port="1521" svc="" link="" pwd=""
  prompt_value src "Current source PDB"; prompt_value tgt "Refreshable clone PDB"; prompt_value sdb "Source DB_UNIQUE_NAME"
  prompt_value scan "Source SCAN/host"; prompt_value port "Listener port" "1521"; prompt_value svc "Source service" "$sdb"
  prompt_value link "Reciprocal DB link"; prompt_secret pwd "Source SYS password"
  run_engine -S -p "$src" -t "$tgt" -s "$sdb" -a "$scan" -P "$port" -g "$svc" -b "$link" -w "$pwd"
}
