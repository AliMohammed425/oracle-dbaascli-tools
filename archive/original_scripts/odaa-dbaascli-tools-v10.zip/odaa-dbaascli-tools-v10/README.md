# ODAA DBaaSCLI Tools v10.0.0

## Run

```bash
./bin/odaa_db_migration.sh
./bin/odaa_db_migration_pdb.sh -H
```

## Install

```bash
./install.sh /home/opc/tools/odaa-dbaascli-tools
```

DBaaSCLI is preferred for local CDB creation; DBCA is the fallback.
The main menu dispatches to the Version 10 core CLI engine.
